import React, { useEffect, useState } from 'react';
import Website from '@/components/elements/custom/social/Website';
import Discord from '@/components/elements/custom/social/Discord';
import Billing from '@/components/elements/custom/social/Billing';
import Status from '@/components/elements/custom/social/Status';
import Knowledgebase from '@/components/elements/custom/social/Knowledgebase';
import getTheme from '@/api/getThemeData';

export default () => {
    const [settings, setSettings] = useState<any>(null);

    useEffect(() => {
        getTheme().then((data) => {
            setSettings(data);
        });
    }, []);

    if (!settings) {
        return null;
    }

    return (
        <>
            {settings.website && settings.website !== 'none' && (
                <Website/>
            )}
            
            {settings.discord && settings.discord !== 'none' && (
                <Discord/>
            )}
            
            {settings.billing && settings.billing !== 'none' && (
                <Billing/>
            )}
            
            {settings.status && settings.status !== 'none' && (
                <Status/>
            )}
            
            {settings.knowledgebase && settings.knowledgebase !== 'none' && (
                <Knowledgebase/>
            )}
        </>
    );
};
